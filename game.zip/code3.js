gdjs._482Code = {};
gdjs._482Code.GDDigitObjects1= [];
gdjs._482Code.GDDigitObjects2= [];
gdjs._482Code.GDDigit2Objects1= [];
gdjs._482Code.GDDigit2Objects2= [];
gdjs._482Code.GDRedFloor2Objects1= [];
gdjs._482Code.GDRedFloor2Objects2= [];
gdjs._482Code.GDRedFloorObjects1= [];
gdjs._482Code.GDRedFloorObjects2= [];
gdjs._482Code.GDGreenPlayerObjects1= [];
gdjs._482Code.GDGreenPlayerObjects2= [];
gdjs._482Code.GDGreenJewelObjects1= [];
gdjs._482Code.GDGreenJewelObjects2= [];
gdjs._482Code.GDScoreValueObjects1= [];
gdjs._482Code.GDScoreValueObjects2= [];
gdjs._482Code.GDScoreObjects1= [];
gdjs._482Code.GDScoreObjects2= [];
gdjs._482Code.GDLVLNameObjects1= [];
gdjs._482Code.GDLVLNameObjects2= [];
gdjs._482Code.GDNewObjectObjects1= [];
gdjs._482Code.GDNewObjectObjects2= [];
gdjs._482Code.GDSmallRedPlatformObjects1= [];
gdjs._482Code.GDSmallRedPlatformObjects2= [];
gdjs._482Code.GDWalkingEnemyObjects1= [];
gdjs._482Code.GDWalkingEnemyObjects2= [];
gdjs._482Code.GDBluePlatformObjects1= [];
gdjs._482Code.GDBluePlatformObjects2= [];
gdjs._482Code.GDYellowPlatformObjects1= [];
gdjs._482Code.GDYellowPlatformObjects2= [];
gdjs._482Code.GDGreenFlagObjects1= [];
gdjs._482Code.GDGreenFlagObjects2= [];
gdjs._482Code.GDGreenBlockObjects1= [];
gdjs._482Code.GDGreenBlockObjects2= [];
gdjs._482Code.GDRedBlockObjects1= [];
gdjs._482Code.GDRedBlockObjects2= [];

gdjs._482Code.conditionTrue_0 = {val:false};
gdjs._482Code.condition0IsTrue_0 = {val:false};
gdjs._482Code.condition1IsTrue_0 = {val:false};
gdjs._482Code.condition2IsTrue_0 = {val:false};
gdjs._482Code.condition3IsTrue_0 = {val:false};


gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._482Code.GDGreenPlayerObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenJewelObjects1Objects = Hashtable.newFrom({"GreenJewel": gdjs._482Code.GDGreenJewelObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._482Code.GDGreenPlayerObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDWalkingEnemyObjects1Objects = Hashtable.newFrom({"WalkingEnemy": gdjs._482Code.GDWalkingEnemyObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDWalkingEnemyObjects1Objects = Hashtable.newFrom({"WalkingEnemy": gdjs._482Code.GDWalkingEnemyObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._482Code.GDGreenPlayerObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._482Code.GDGreenPlayerObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDBluePlatformObjects1Objects = Hashtable.newFrom({"BluePlatform": gdjs._482Code.GDBluePlatformObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._482Code.GDGreenPlayerObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDYellowPlatformObjects1Objects = Hashtable.newFrom({"YellowPlatform": gdjs._482Code.GDYellowPlatformObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._482Code.GDGreenPlayerObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDRedFloorObjects1Objects = Hashtable.newFrom({"RedFloor": gdjs._482Code.GDRedFloorObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._482Code.GDGreenPlayerObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenFlagObjects1Objects = Hashtable.newFrom({"GreenFlag": gdjs._482Code.GDGreenFlagObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenBlockObjects1Objects = Hashtable.newFrom({"GreenBlock": gdjs._482Code.GDGreenBlockObjects1});gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDYellowPlatformObjects1Objects = Hashtable.newFrom({"YellowPlatform": gdjs._482Code.GDYellowPlatformObjects1});gdjs._482Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._482Code.GDGreenPlayerObjects1);

gdjs._482Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._482Code.GDGreenPlayerObjects1.length;i<l;++i) {
    if ( gdjs._482Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs._482Code.condition0IsTrue_0.val = true;
        gdjs._482Code.GDGreenPlayerObjects1[k] = gdjs._482Code.GDGreenPlayerObjects1[i];
        ++k;
    }
}
gdjs._482Code.GDGreenPlayerObjects1.length = k;}if (gdjs._482Code.condition0IsTrue_0.val) {
/* Reuse gdjs._482Code.GDGreenPlayerObjects1 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs._482Code.GDGreenPlayerObjects1.length !== 0 ? gdjs._482Code.GDGreenPlayerObjects1[0] : null), true, "", 0);
}}

}


{


gdjs._482Code.condition0IsTrue_0.val = false;
{
gdjs._482Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._482Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._482Code.GDGreenPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("LVLName"), gdjs._482Code.GDLVLNameObjects1);
gdjs.copyArray(runtimeScene.getObjects("ScoreValue"), gdjs._482Code.GDScoreValueObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs._482Code.GDGreenPlayerObjects1.length !== 0 ? gdjs._482Code.GDGreenPlayerObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs._482Code.GDScoreValueObjects1.length ;i < len;++i) {
    gdjs._482Code.GDScoreValueObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs._482Code.GDLVLNameObjects1.length ;i < len;++i) {
    gdjs._482Code.GDLVLNameObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("01")));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Time");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenJewel"), gdjs._482Code.GDGreenJewelObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._482Code.GDGreenPlayerObjects1);

gdjs._482Code.condition0IsTrue_0.val = false;
{
gdjs._482Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects, gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenJewelObjects1Objects, false, runtimeScene, false);
}if (gdjs._482Code.condition0IsTrue_0.val) {
/* Reuse gdjs._482Code.GDGreenJewelObjects1 */
gdjs.copyArray(runtimeScene.getObjects("ScoreValue"), gdjs._482Code.GDScoreValueObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(10);
}{for(var i = 0, len = gdjs._482Code.GDGreenJewelObjects1.length ;i < len;++i) {
    gdjs._482Code.GDGreenJewelObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._482Code.GDScoreValueObjects1.length ;i < len;++i) {
    gdjs._482Code.GDScoreValueObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


{


gdjs._482Code.condition0IsTrue_0.val = false;
{
gdjs._482Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs._482Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._482Code.GDGreenPlayerObjects1);
{for(var i = 0, len = gdjs._482Code.GDGreenPlayerObjects1.length ;i < len;++i) {
    gdjs._482Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{


gdjs._482Code.condition0IsTrue_0.val = false;
{
gdjs._482Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs._482Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._482Code.GDGreenPlayerObjects1);
{for(var i = 0, len = gdjs._482Code.GDGreenPlayerObjects1.length ;i < len;++i) {
    gdjs._482Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{


gdjs._482Code.condition0IsTrue_0.val = false;
gdjs._482Code.condition1IsTrue_0.val = false;
gdjs._482Code.condition2IsTrue_0.val = false;
{
gdjs._482Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if ( gdjs._482Code.condition0IsTrue_0.val ) {
{
gdjs._482Code.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if ( gdjs._482Code.condition1IsTrue_0.val ) {
{
gdjs._482Code.condition2IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
}}
}
if (gdjs._482Code.condition2IsTrue_0.val) {
{gdjs.evtTools.debuggerTools.enableDebugDraw(runtimeScene, true, true, true, true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._482Code.GDGreenPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("WalkingEnemy"), gdjs._482Code.GDWalkingEnemyObjects1);

gdjs._482Code.condition0IsTrue_0.val = false;
gdjs._482Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._482Code.GDGreenPlayerObjects1.length;i<l;++i) {
    if ( gdjs._482Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs._482Code.condition0IsTrue_0.val = true;
        gdjs._482Code.GDGreenPlayerObjects1[k] = gdjs._482Code.GDGreenPlayerObjects1[i];
        ++k;
    }
}
gdjs._482Code.GDGreenPlayerObjects1.length = k;}if ( gdjs._482Code.condition0IsTrue_0.val ) {
{
gdjs._482Code.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects, gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDWalkingEnemyObjects1Objects, false, runtimeScene, false);
}}
if (gdjs._482Code.condition1IsTrue_0.val) {
/* Reuse gdjs._482Code.GDGreenPlayerObjects1 */
/* Reuse gdjs._482Code.GDWalkingEnemyObjects1 */
{for(var i = 0, len = gdjs._482Code.GDWalkingEnemyObjects1.length ;i < len;++i) {
    gdjs._482Code.GDWalkingEnemyObjects1[i].setAnimationName("dead");
}
}{for(var i = 0, len = gdjs._482Code.GDGreenPlayerObjects1.length ;i < len;++i) {
    gdjs._482Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs._482Code.GDWalkingEnemyObjects1.length ;i < len;++i) {
    gdjs._482Code.GDWalkingEnemyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._482Code.GDGreenPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("WalkingEnemy"), gdjs._482Code.GDWalkingEnemyObjects1);

gdjs._482Code.condition0IsTrue_0.val = false;
gdjs._482Code.condition1IsTrue_0.val = false;
{
gdjs._482Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDWalkingEnemyObjects1Objects, gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects, false, runtimeScene, false);
}if ( gdjs._482Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._482Code.GDGreenPlayerObjects1.length;i<l;++i) {
    if ( gdjs._482Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs._482Code.condition1IsTrue_0.val = true;
        gdjs._482Code.GDGreenPlayerObjects1[k] = gdjs._482Code.GDGreenPlayerObjects1[i];
        ++k;
    }
}
gdjs._482Code.GDGreenPlayerObjects1.length = k;}}
if (gdjs._482Code.condition1IsTrue_0.val) {
/* Reuse gdjs._482Code.GDGreenPlayerObjects1 */
{for(var i = 0, len = gdjs._482Code.GDGreenPlayerObjects1.length ;i < len;++i) {
    gdjs._482Code.GDGreenPlayerObjects1[i].setAnimationName("dead");
}
}{gdjs.evtTools.storage.writeNumberInJSONFile("player", "score", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "02", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BluePlatform"), gdjs._482Code.GDBluePlatformObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._482Code.GDGreenPlayerObjects1);

gdjs._482Code.condition0IsTrue_0.val = false;
{
gdjs._482Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects, gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDBluePlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs._482Code.condition0IsTrue_0.val) {
/* Reuse gdjs._482Code.GDGreenPlayerObjects1 */
{for(var i = 0, len = gdjs._482Code.GDGreenPlayerObjects1.length ;i < len;++i) {
    gdjs._482Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").setGravity(300);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._482Code.GDGreenPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("YellowPlatform"), gdjs._482Code.GDYellowPlatformObjects1);

gdjs._482Code.condition0IsTrue_0.val = false;
{
gdjs._482Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects, gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDYellowPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs._482Code.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("player", "score", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "02", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._482Code.GDGreenPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedFloor"), gdjs._482Code.GDRedFloorObjects1);

gdjs._482Code.condition0IsTrue_0.val = false;
{
gdjs._482Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects, gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDRedFloorObjects1Objects, false, runtimeScene, false);
}if (gdjs._482Code.condition0IsTrue_0.val) {
/* Reuse gdjs._482Code.GDGreenPlayerObjects1 */
{for(var i = 0, len = gdjs._482Code.GDGreenPlayerObjects1.length ;i < len;++i) {
    gdjs._482Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").setGravity(500);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenFlag"), gdjs._482Code.GDGreenFlagObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._482Code.GDGreenPlayerObjects1);

gdjs._482Code.condition0IsTrue_0.val = false;
{
gdjs._482Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenPlayerObjects1Objects, gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenFlagObjects1Objects, false, runtimeScene, false);
}if (gdjs._482Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level Select", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenBlock"), gdjs._482Code.GDGreenBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("YellowPlatform"), gdjs._482Code.GDYellowPlatformObjects1);

gdjs._482Code.condition0IsTrue_0.val = false;
{
gdjs._482Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDGreenBlockObjects1Objects, gdjs._482Code.mapOfGDgdjs_46_95482Code_46GDYellowPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs._482Code.condition0IsTrue_0.val) {
/* Reuse gdjs._482Code.GDGreenBlockObjects1 */
{for(var i = 0, len = gdjs._482Code.GDGreenBlockObjects1.length ;i < len;++i) {
    gdjs._482Code.GDGreenBlockObjects1[i].setX(704);
}
}{for(var i = 0, len = gdjs._482Code.GDGreenBlockObjects1.length ;i < len;++i) {
    gdjs._482Code.GDGreenBlockObjects1[i].setY(448);
}
}}

}


};

gdjs._482Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._482Code.GDDigitObjects1.length = 0;
gdjs._482Code.GDDigitObjects2.length = 0;
gdjs._482Code.GDDigit2Objects1.length = 0;
gdjs._482Code.GDDigit2Objects2.length = 0;
gdjs._482Code.GDRedFloor2Objects1.length = 0;
gdjs._482Code.GDRedFloor2Objects2.length = 0;
gdjs._482Code.GDRedFloorObjects1.length = 0;
gdjs._482Code.GDRedFloorObjects2.length = 0;
gdjs._482Code.GDGreenPlayerObjects1.length = 0;
gdjs._482Code.GDGreenPlayerObjects2.length = 0;
gdjs._482Code.GDGreenJewelObjects1.length = 0;
gdjs._482Code.GDGreenJewelObjects2.length = 0;
gdjs._482Code.GDScoreValueObjects1.length = 0;
gdjs._482Code.GDScoreValueObjects2.length = 0;
gdjs._482Code.GDScoreObjects1.length = 0;
gdjs._482Code.GDScoreObjects2.length = 0;
gdjs._482Code.GDLVLNameObjects1.length = 0;
gdjs._482Code.GDLVLNameObjects2.length = 0;
gdjs._482Code.GDNewObjectObjects1.length = 0;
gdjs._482Code.GDNewObjectObjects2.length = 0;
gdjs._482Code.GDSmallRedPlatformObjects1.length = 0;
gdjs._482Code.GDSmallRedPlatformObjects2.length = 0;
gdjs._482Code.GDWalkingEnemyObjects1.length = 0;
gdjs._482Code.GDWalkingEnemyObjects2.length = 0;
gdjs._482Code.GDBluePlatformObjects1.length = 0;
gdjs._482Code.GDBluePlatformObjects2.length = 0;
gdjs._482Code.GDYellowPlatformObjects1.length = 0;
gdjs._482Code.GDYellowPlatformObjects2.length = 0;
gdjs._482Code.GDGreenFlagObjects1.length = 0;
gdjs._482Code.GDGreenFlagObjects2.length = 0;
gdjs._482Code.GDGreenBlockObjects1.length = 0;
gdjs._482Code.GDGreenBlockObjects2.length = 0;
gdjs._482Code.GDRedBlockObjects1.length = 0;
gdjs._482Code.GDRedBlockObjects2.length = 0;

gdjs._482Code.eventsList0(runtimeScene);
return;

}

gdjs['_482Code'] = gdjs._482Code;
