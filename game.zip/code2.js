gdjs._481Code = {};
gdjs._481Code.GDDigitObjects1= [];
gdjs._481Code.GDDigitObjects2= [];
gdjs._481Code.GDDigit2Objects1= [];
gdjs._481Code.GDDigit2Objects2= [];
gdjs._481Code.GDRedFloor2Objects1= [];
gdjs._481Code.GDRedFloor2Objects2= [];
gdjs._481Code.GDRedFloorObjects1= [];
gdjs._481Code.GDRedFloorObjects2= [];
gdjs._481Code.GDGreenPlayerObjects1= [];
gdjs._481Code.GDGreenPlayerObjects2= [];
gdjs._481Code.GDGreenJewelObjects1= [];
gdjs._481Code.GDGreenJewelObjects2= [];
gdjs._481Code.GDScoreValueObjects1= [];
gdjs._481Code.GDScoreValueObjects2= [];
gdjs._481Code.GDScoreObjects1= [];
gdjs._481Code.GDScoreObjects2= [];
gdjs._481Code.GDLVLNameObjects1= [];
gdjs._481Code.GDLVLNameObjects2= [];
gdjs._481Code.GDNewObjectObjects1= [];
gdjs._481Code.GDNewObjectObjects2= [];
gdjs._481Code.GDSmallRedPlatformObjects1= [];
gdjs._481Code.GDSmallRedPlatformObjects2= [];
gdjs._481Code.GDWalkingEnemyObjects1= [];
gdjs._481Code.GDWalkingEnemyObjects2= [];
gdjs._481Code.GDBluePlatformObjects1= [];
gdjs._481Code.GDBluePlatformObjects2= [];
gdjs._481Code.GDYellowPlatformObjects1= [];
gdjs._481Code.GDYellowPlatformObjects2= [];
gdjs._481Code.GDGreenFlagObjects1= [];
gdjs._481Code.GDGreenFlagObjects2= [];

gdjs._481Code.conditionTrue_0 = {val:false};
gdjs._481Code.condition0IsTrue_0 = {val:false};
gdjs._481Code.condition1IsTrue_0 = {val:false};
gdjs._481Code.condition2IsTrue_0 = {val:false};
gdjs._481Code.condition3IsTrue_0 = {val:false};


gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._481Code.GDGreenPlayerObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenJewelObjects1Objects = Hashtable.newFrom({"GreenJewel": gdjs._481Code.GDGreenJewelObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._481Code.GDGreenPlayerObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDWalkingEnemyObjects1Objects = Hashtable.newFrom({"WalkingEnemy": gdjs._481Code.GDWalkingEnemyObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDWalkingEnemyObjects1Objects = Hashtable.newFrom({"WalkingEnemy": gdjs._481Code.GDWalkingEnemyObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._481Code.GDGreenPlayerObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._481Code.GDGreenPlayerObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDBluePlatformObjects1Objects = Hashtable.newFrom({"BluePlatform": gdjs._481Code.GDBluePlatformObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._481Code.GDGreenPlayerObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDYellowPlatformObjects1Objects = Hashtable.newFrom({"YellowPlatform": gdjs._481Code.GDYellowPlatformObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._481Code.GDGreenPlayerObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDRedFloorObjects1Objects = Hashtable.newFrom({"RedFloor": gdjs._481Code.GDRedFloorObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects = Hashtable.newFrom({"GreenPlayer": gdjs._481Code.GDGreenPlayerObjects1});gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenFlagObjects1Objects = Hashtable.newFrom({"GreenFlag": gdjs._481Code.GDGreenFlagObjects1});gdjs._481Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._481Code.GDGreenPlayerObjects1);

gdjs._481Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._481Code.GDGreenPlayerObjects1.length;i<l;++i) {
    if ( gdjs._481Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs._481Code.condition0IsTrue_0.val = true;
        gdjs._481Code.GDGreenPlayerObjects1[k] = gdjs._481Code.GDGreenPlayerObjects1[i];
        ++k;
    }
}
gdjs._481Code.GDGreenPlayerObjects1.length = k;}if (gdjs._481Code.condition0IsTrue_0.val) {
/* Reuse gdjs._481Code.GDGreenPlayerObjects1 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs._481Code.GDGreenPlayerObjects1.length !== 0 ? gdjs._481Code.GDGreenPlayerObjects1[0] : null), true, "", 0);
}}

}


{


gdjs._481Code.condition0IsTrue_0.val = false;
{
gdjs._481Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._481Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._481Code.GDGreenPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("LVLName"), gdjs._481Code.GDLVLNameObjects1);
gdjs.copyArray(runtimeScene.getObjects("ScoreValue"), gdjs._481Code.GDScoreValueObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs._481Code.GDGreenPlayerObjects1.length !== 0 ? gdjs._481Code.GDGreenPlayerObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs._481Code.GDScoreValueObjects1.length ;i < len;++i) {
    gdjs._481Code.GDScoreValueObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs._481Code.GDLVLNameObjects1.length ;i < len;++i) {
    gdjs._481Code.GDLVLNameObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("01")));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Time");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenJewel"), gdjs._481Code.GDGreenJewelObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._481Code.GDGreenPlayerObjects1);

gdjs._481Code.condition0IsTrue_0.val = false;
{
gdjs._481Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects, gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenJewelObjects1Objects, false, runtimeScene, false);
}if (gdjs._481Code.condition0IsTrue_0.val) {
/* Reuse gdjs._481Code.GDGreenJewelObjects1 */
gdjs.copyArray(runtimeScene.getObjects("ScoreValue"), gdjs._481Code.GDScoreValueObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(10);
}{for(var i = 0, len = gdjs._481Code.GDGreenJewelObjects1.length ;i < len;++i) {
    gdjs._481Code.GDGreenJewelObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._481Code.GDScoreValueObjects1.length ;i < len;++i) {
    gdjs._481Code.GDScoreValueObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


{


gdjs._481Code.condition0IsTrue_0.val = false;
{
gdjs._481Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs._481Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._481Code.GDGreenPlayerObjects1);
{for(var i = 0, len = gdjs._481Code.GDGreenPlayerObjects1.length ;i < len;++i) {
    gdjs._481Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{


gdjs._481Code.condition0IsTrue_0.val = false;
{
gdjs._481Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs._481Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._481Code.GDGreenPlayerObjects1);
{for(var i = 0, len = gdjs._481Code.GDGreenPlayerObjects1.length ;i < len;++i) {
    gdjs._481Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{


gdjs._481Code.condition0IsTrue_0.val = false;
gdjs._481Code.condition1IsTrue_0.val = false;
gdjs._481Code.condition2IsTrue_0.val = false;
{
gdjs._481Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if ( gdjs._481Code.condition0IsTrue_0.val ) {
{
gdjs._481Code.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if ( gdjs._481Code.condition1IsTrue_0.val ) {
{
gdjs._481Code.condition2IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
}}
}
if (gdjs._481Code.condition2IsTrue_0.val) {
{gdjs.evtTools.debuggerTools.enableDebugDraw(runtimeScene, true, true, true, true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._481Code.GDGreenPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("WalkingEnemy"), gdjs._481Code.GDWalkingEnemyObjects1);

gdjs._481Code.condition0IsTrue_0.val = false;
gdjs._481Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._481Code.GDGreenPlayerObjects1.length;i<l;++i) {
    if ( gdjs._481Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs._481Code.condition0IsTrue_0.val = true;
        gdjs._481Code.GDGreenPlayerObjects1[k] = gdjs._481Code.GDGreenPlayerObjects1[i];
        ++k;
    }
}
gdjs._481Code.GDGreenPlayerObjects1.length = k;}if ( gdjs._481Code.condition0IsTrue_0.val ) {
{
gdjs._481Code.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects, gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDWalkingEnemyObjects1Objects, false, runtimeScene, false);
}}
if (gdjs._481Code.condition1IsTrue_0.val) {
/* Reuse gdjs._481Code.GDGreenPlayerObjects1 */
/* Reuse gdjs._481Code.GDWalkingEnemyObjects1 */
{for(var i = 0, len = gdjs._481Code.GDWalkingEnemyObjects1.length ;i < len;++i) {
    gdjs._481Code.GDWalkingEnemyObjects1[i].setAnimationName("dead");
}
}{for(var i = 0, len = gdjs._481Code.GDGreenPlayerObjects1.length ;i < len;++i) {
    gdjs._481Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs._481Code.GDWalkingEnemyObjects1.length ;i < len;++i) {
    gdjs._481Code.GDWalkingEnemyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._481Code.GDGreenPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("WalkingEnemy"), gdjs._481Code.GDWalkingEnemyObjects1);

gdjs._481Code.condition0IsTrue_0.val = false;
gdjs._481Code.condition1IsTrue_0.val = false;
{
gdjs._481Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDWalkingEnemyObjects1Objects, gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects, false, runtimeScene, false);
}if ( gdjs._481Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._481Code.GDGreenPlayerObjects1.length;i<l;++i) {
    if ( gdjs._481Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs._481Code.condition1IsTrue_0.val = true;
        gdjs._481Code.GDGreenPlayerObjects1[k] = gdjs._481Code.GDGreenPlayerObjects1[i];
        ++k;
    }
}
gdjs._481Code.GDGreenPlayerObjects1.length = k;}}
if (gdjs._481Code.condition1IsTrue_0.val) {
/* Reuse gdjs._481Code.GDGreenPlayerObjects1 */
{for(var i = 0, len = gdjs._481Code.GDGreenPlayerObjects1.length ;i < len;++i) {
    gdjs._481Code.GDGreenPlayerObjects1[i].setAnimationName("dead");
}
}{gdjs.evtTools.storage.writeNumberInJSONFile("player", "score", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "01", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BluePlatform"), gdjs._481Code.GDBluePlatformObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._481Code.GDGreenPlayerObjects1);

gdjs._481Code.condition0IsTrue_0.val = false;
{
gdjs._481Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects, gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDBluePlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs._481Code.condition0IsTrue_0.val) {
/* Reuse gdjs._481Code.GDGreenPlayerObjects1 */
{for(var i = 0, len = gdjs._481Code.GDGreenPlayerObjects1.length ;i < len;++i) {
    gdjs._481Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").setGravity(300);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._481Code.GDGreenPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("YellowPlatform"), gdjs._481Code.GDYellowPlatformObjects1);

gdjs._481Code.condition0IsTrue_0.val = false;
{
gdjs._481Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects, gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDYellowPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs._481Code.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("player", "score", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "01", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._481Code.GDGreenPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedFloor"), gdjs._481Code.GDRedFloorObjects1);

gdjs._481Code.condition0IsTrue_0.val = false;
{
gdjs._481Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects, gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDRedFloorObjects1Objects, false, runtimeScene, false);
}if (gdjs._481Code.condition0IsTrue_0.val) {
/* Reuse gdjs._481Code.GDGreenPlayerObjects1 */
{for(var i = 0, len = gdjs._481Code.GDGreenPlayerObjects1.length ;i < len;++i) {
    gdjs._481Code.GDGreenPlayerObjects1[i].getBehavior("PlatformerObject").setGravity(500);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenFlag"), gdjs._481Code.GDGreenFlagObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreenPlayer"), gdjs._481Code.GDGreenPlayerObjects1);

gdjs._481Code.condition0IsTrue_0.val = false;
{
gdjs._481Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenPlayerObjects1Objects, gdjs._481Code.mapOfGDgdjs_46_95481Code_46GDGreenFlagObjects1Objects, false, runtimeScene, false);
}if (gdjs._481Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level Select", false);
}}

}


};

gdjs._481Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._481Code.GDDigitObjects1.length = 0;
gdjs._481Code.GDDigitObjects2.length = 0;
gdjs._481Code.GDDigit2Objects1.length = 0;
gdjs._481Code.GDDigit2Objects2.length = 0;
gdjs._481Code.GDRedFloor2Objects1.length = 0;
gdjs._481Code.GDRedFloor2Objects2.length = 0;
gdjs._481Code.GDRedFloorObjects1.length = 0;
gdjs._481Code.GDRedFloorObjects2.length = 0;
gdjs._481Code.GDGreenPlayerObjects1.length = 0;
gdjs._481Code.GDGreenPlayerObjects2.length = 0;
gdjs._481Code.GDGreenJewelObjects1.length = 0;
gdjs._481Code.GDGreenJewelObjects2.length = 0;
gdjs._481Code.GDScoreValueObjects1.length = 0;
gdjs._481Code.GDScoreValueObjects2.length = 0;
gdjs._481Code.GDScoreObjects1.length = 0;
gdjs._481Code.GDScoreObjects2.length = 0;
gdjs._481Code.GDLVLNameObjects1.length = 0;
gdjs._481Code.GDLVLNameObjects2.length = 0;
gdjs._481Code.GDNewObjectObjects1.length = 0;
gdjs._481Code.GDNewObjectObjects2.length = 0;
gdjs._481Code.GDSmallRedPlatformObjects1.length = 0;
gdjs._481Code.GDSmallRedPlatformObjects2.length = 0;
gdjs._481Code.GDWalkingEnemyObjects1.length = 0;
gdjs._481Code.GDWalkingEnemyObjects2.length = 0;
gdjs._481Code.GDBluePlatformObjects1.length = 0;
gdjs._481Code.GDBluePlatformObjects2.length = 0;
gdjs._481Code.GDYellowPlatformObjects1.length = 0;
gdjs._481Code.GDYellowPlatformObjects2.length = 0;
gdjs._481Code.GDGreenFlagObjects1.length = 0;
gdjs._481Code.GDGreenFlagObjects2.length = 0;

gdjs._481Code.eventsList0(runtimeScene);
return;

}

gdjs['_481Code'] = gdjs._481Code;
