gdjs.Level_32SelectCode = {};
gdjs.Level_32SelectCode.GDIconBackground2Objects1= [];
gdjs.Level_32SelectCode.GDIconBackground2Objects2= [];
gdjs.Level_32SelectCode.GDIconBackgroundObjects1= [];
gdjs.Level_32SelectCode.GDIconBackgroundObjects2= [];
gdjs.Level_32SelectCode.GDDigit2Objects1= [];
gdjs.Level_32SelectCode.GDDigit2Objects2= [];
gdjs.Level_32SelectCode.GDLVLName2Objects1= [];
gdjs.Level_32SelectCode.GDLVLName2Objects2= [];
gdjs.Level_32SelectCode.GDLVLNameObjects1= [];
gdjs.Level_32SelectCode.GDLVLNameObjects2= [];
gdjs.Level_32SelectCode.GDDigitObjects1= [];
gdjs.Level_32SelectCode.GDDigitObjects2= [];
gdjs.Level_32SelectCode.GDHomeObjects1= [];
gdjs.Level_32SelectCode.GDHomeObjects2= [];

gdjs.Level_32SelectCode.conditionTrue_0 = {val:false};
gdjs.Level_32SelectCode.condition0IsTrue_0 = {val:false};
gdjs.Level_32SelectCode.condition1IsTrue_0 = {val:false};
gdjs.Level_32SelectCode.condition2IsTrue_0 = {val:false};


gdjs.Level_32SelectCode.mapOfGDgdjs_46Level_9532SelectCode_46GDLVLNameObjects1Objects = Hashtable.newFrom({"LVLName": gdjs.Level_32SelectCode.GDLVLNameObjects1});gdjs.Level_32SelectCode.mapOfGDgdjs_46Level_9532SelectCode_46GDLVLName2Objects1Objects = Hashtable.newFrom({"LVLName2": gdjs.Level_32SelectCode.GDLVLName2Objects1});gdjs.Level_32SelectCode.mapOfGDgdjs_46Level_9532SelectCode_46GDHomeObjects1Objects = Hashtable.newFrom({"Home": gdjs.Level_32SelectCode.GDHomeObjects1});gdjs.Level_32SelectCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LVLName"), gdjs.Level_32SelectCode.GDLVLNameObjects1);

gdjs.Level_32SelectCode.condition0IsTrue_0.val = false;
gdjs.Level_32SelectCode.condition1IsTrue_0.val = false;
{
gdjs.Level_32SelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_32SelectCode.condition0IsTrue_0.val ) {
{
gdjs.Level_32SelectCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_32SelectCode.mapOfGDgdjs_46Level_9532SelectCode_46GDLVLNameObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.Level_32SelectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "01", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LVLName2"), gdjs.Level_32SelectCode.GDLVLName2Objects1);

gdjs.Level_32SelectCode.condition0IsTrue_0.val = false;
gdjs.Level_32SelectCode.condition1IsTrue_0.val = false;
{
gdjs.Level_32SelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_32SelectCode.condition0IsTrue_0.val ) {
{
gdjs.Level_32SelectCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_32SelectCode.mapOfGDgdjs_46Level_9532SelectCode_46GDLVLName2Objects1Objects, runtimeScene, true, false);
}}
if (gdjs.Level_32SelectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "02", false);
}}

}


{


gdjs.Level_32SelectCode.condition0IsTrue_0.val = false;
{
gdjs.Level_32SelectCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_32SelectCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LVLName"), gdjs.Level_32SelectCode.GDLVLNameObjects1);
gdjs.copyArray(runtimeScene.getObjects("LVLName2"), gdjs.Level_32SelectCode.GDLVLName2Objects1);
{for(var i = 0, len = gdjs.Level_32SelectCode.GDLVLNameObjects1.length ;i < len;++i) {
    gdjs.Level_32SelectCode.GDLVLNameObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("01")));
}
}{for(var i = 0, len = gdjs.Level_32SelectCode.GDLVLName2Objects1.length ;i < len;++i) {
    gdjs.Level_32SelectCode.GDLVLName2Objects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("02")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Home"), gdjs.Level_32SelectCode.GDHomeObjects1);

gdjs.Level_32SelectCode.condition0IsTrue_0.val = false;
gdjs.Level_32SelectCode.condition1IsTrue_0.val = false;
{
gdjs.Level_32SelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_32SelectCode.condition0IsTrue_0.val ) {
{
gdjs.Level_32SelectCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_32SelectCode.mapOfGDgdjs_46Level_9532SelectCode_46GDHomeObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.Level_32SelectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Start", false);
}}

}


};

gdjs.Level_32SelectCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_32SelectCode.GDIconBackground2Objects1.length = 0;
gdjs.Level_32SelectCode.GDIconBackground2Objects2.length = 0;
gdjs.Level_32SelectCode.GDIconBackgroundObjects1.length = 0;
gdjs.Level_32SelectCode.GDIconBackgroundObjects2.length = 0;
gdjs.Level_32SelectCode.GDDigit2Objects1.length = 0;
gdjs.Level_32SelectCode.GDDigit2Objects2.length = 0;
gdjs.Level_32SelectCode.GDLVLName2Objects1.length = 0;
gdjs.Level_32SelectCode.GDLVLName2Objects2.length = 0;
gdjs.Level_32SelectCode.GDLVLNameObjects1.length = 0;
gdjs.Level_32SelectCode.GDLVLNameObjects2.length = 0;
gdjs.Level_32SelectCode.GDDigitObjects1.length = 0;
gdjs.Level_32SelectCode.GDDigitObjects2.length = 0;
gdjs.Level_32SelectCode.GDHomeObjects1.length = 0;
gdjs.Level_32SelectCode.GDHomeObjects2.length = 0;

gdjs.Level_32SelectCode.eventsList0(runtimeScene);
return;

}

gdjs['Level_32SelectCode'] = gdjs.Level_32SelectCode;
